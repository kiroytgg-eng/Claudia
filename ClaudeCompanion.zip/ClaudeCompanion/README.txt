CLAUDE COMPANION - Forge 1.20.1

COMPILAR: copia este src/ sobre el MDK de Forge 1.20.1 (47.x), mod_id=claudecompanion, gradlew build.

AJUSTES (pantalla): boton "Config" en Mod Menu, o escribe /claudeconfig en el juego.
 - API key y modelo de Gemini (por defecto gemini-flash-latest), nombre, corazones (500 por defecto),
   personalidad (amigo / bullying / menso), skin (6), responder a todo, dar objetos.
 - Tambien esta en config/claudecompanion-common.toml

COMANDOS
 /claude spawn | despawn      cuerpo de jugador (te sigue, pelea)
 /claude casa                 construye una casa poco a poco (tambien si se lo pides en el chat)
 /claude modo amigo|bullying|menso
 /claude nombre <texto>
 /claude skin <1-6>
 /claude reset                borra la memoria de la conversacion
 Si Claude muere, avisa en amarillo en el chat: "<nombre> murio por ..."

CHAT: con su cuerpo invocado responde a todo; si no, cuando dices su nombre.
Skins: src/main/resources/assets/claudecompanion/textures/entity/claude_0..5.png (64x64, cambialas si quieres)
