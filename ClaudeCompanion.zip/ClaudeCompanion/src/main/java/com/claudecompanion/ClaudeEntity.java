package com.claudecompanion;

import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.*;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.AxeItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.ChestBlock;
import net.minecraft.world.level.block.DoorBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.DoubleBlockHalf;

import java.util.ArrayDeque;
import java.util.EnumSet;
import java.util.UUID;

/** El cuerpo de jugador de Claude: te sigue, pelea, tiene 500 corazones, cambia de skin y construye casas. */
public class ClaudeEntity extends PathfinderMob {
    private static final EntityDataAccessor<Integer> SKIN =
            SynchedEntityData.defineId(ClaudeEntity.class, EntityDataSerializers.INT);

    private record BuildStep(BlockPos pos, BlockState state) {}

    private UUID ownerId;
    private final ArrayDeque<BuildStep> buildQueue = new ArrayDeque<>();
    private BlockPos buildCenter;
    private int buildTimer;

    public ClaudeEntity(EntityType<? extends PathfinderMob> type, Level level) {
        super(type, level);
        this.setPersistenceRequired();
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 1000.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.3D)
                .add(Attributes.ATTACK_DAMAGE, 3.0D)
                .add(Attributes.FOLLOW_RANGE, 32.0D);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(SKIN, 0);
    }

    public int getSkin() { return this.entityData.get(SKIN); }

    /** Aplica nombre, skin y corazones segun el config. */
    public void applyConfig() {
        this.entityData.set(SKIN, Config.SKIN.get());
        this.setCustomName(Component.literal(Config.NAME.get()));
        this.setCustomNameVisible(true);
        AttributeInstance inst = this.getAttribute(Attributes.MAX_HEALTH);
        if (inst != null) inst.setBaseValue(Config.HEARTS.get() * 2.0D);
        this.setHealth(this.getMaxHealth());
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new MeleeAttackGoal(this, 1.15D, true));
        this.goalSelector.addGoal(2, new FollowOwnerGoal(this));
        this.goalSelector.addGoal(3, new WaterAvoidingRandomStrollGoal(this, 0.8D));
        this.goalSelector.addGoal(4, new LookAtPlayerGoal(this, Player.class, 8.0F));
        this.goalSelector.addGoal(5, new RandomLookAroundGoal(this));
        this.targetSelector.addGoal(1, new NearestAttackableTargetGoal<>(this, Monster.class, true));
    }

    public void setOwner(Player p) { this.ownerId = p.getUUID(); }

    public UUID getOwnerId() { return ownerId; }

    Player getOwner() {
        return ownerId == null ? null : this.level().getPlayerByUUID(ownerId);
    }

    public boolean isBuilding() { return !buildQueue.isEmpty(); }

    @Override
    public boolean removeWhenFarAway(double d) { return false; }

    // ---------- tick ----------
    @Override
    public void aiStep() {
        super.aiStep();
        if (this.level().isClientSide) return;

        if (this.tickCount % 20 == 0) {
            int skin = Config.SKIN.get();
            if (this.entityData.get(SKIN) != skin) this.entityData.set(SKIN, skin);

            String want = Config.NAME.get();
            Component cur = this.getCustomName();
            if (cur == null || !want.equals(cur.getString())) this.setCustomName(Component.literal(want));
            this.setCustomNameVisible(true);

            double maxWanted = Config.HEARTS.get() * 2.0D;
            AttributeInstance inst = this.getAttribute(Attributes.MAX_HEALTH);
            if (inst != null && inst.getBaseValue() != maxWanted) {
                inst.setBaseValue(maxWanted);
                if (this.getHealth() > maxWanted) this.setHealth((float) maxWanted);
            }
            if (this.getHealth() < this.getMaxHealth()) this.heal(2.0F);
        }
        tickBuild();
    }

    // ---------- muerte ----------
    @Override
    public void die(DamageSource source) {
        super.die(source);
        if (!this.level().isClientSide && this.level().getServer() != null) {
            MutableComponent msg = Component.literal(Config.NAME.get() + " murió por ")
                    .append(deathCause(source))
                    .withStyle(ChatFormatting.YELLOW);
            this.level().getServer().getPlayerList().broadcastSystemMessage(msg, false);
        }
    }

    private Component deathCause(DamageSource src) {
        Entity attacker = src.getEntity();
        if (attacker != null) return attacker.getDisplayName();
        String id = src.getMsgId();
        String txt = switch (id) {
            case "fall" -> "una caída";
            case "lava" -> "lava";
            case "inFire", "onFire" -> "fuego";
            case "drown" -> "ahogamiento";
            case "explosion", "explosion.player" -> "una explosión";
            case "cactus" -> "un cactus";
            case "starve" -> "hambre";
            case "outOfWorld" -> "caer al vacío";
            case "fallingBlock", "anvil" -> "un bloque que cayó";
            case "lightningBolt" -> "un rayo";
            case "magic", "indirectMagic" -> "magia";
            case "wither" -> "el efecto wither";
            case "freeze" -> "congelamiento";
            case "sweetBerryBush" -> "arbustos de bayas";
            case "hotFloor" -> "magma";
            case "inWall" -> "asfixia";
            case "cramming" -> "aplastamiento";
            case "genericKill" -> "un comando";
            default -> id;
        };
        return Component.literal(txt);
    }

    // ---------- construir casas ----------
    private static BlockPos at(BlockPos base, Direction right, Direction fwd, int lx, int lz, int y) {
        return new BlockPos(
                base.getX() + right.getStepX() * lx + fwd.getStepX() * lz,
                y,
                base.getZ() + right.getStepZ() * lx + fwd.getStepZ() * lz);
    }

    private void add(BlockPos p, BlockState s) { buildQueue.add(new BuildStep(p, s)); }

    private static boolean isWindow(int lx, int lz) {
        return (Math.abs(lx) == 3 && (lz == 2 || lz == 4))
                || (lz == 6 && Math.abs(lx) == 1)
                || (lz == 0 && Math.abs(lx) == 2);
    }

    /** Planea una casita de 7x7 frente al jugador; se construye poco a poco. */
    public boolean startHouse(Player owner) {
        if (!buildQueue.isEmpty()) return false;
        Direction dir = owner.getDirection();
        Direction right = dir.getClockWise();
        BlockPos base = owner.blockPosition().relative(dir, 3);
        int fy = owner.blockPosition().getY() - 1;

        // 1) despejar
        for (int y = fy + 6; y >= fy + 1; y--)
            for (int lz = 0; lz < 7; lz++)
                for (int lx = -3; lx <= 3; lx++)
                    add(at(base, right, dir, lx, lz, y), Blocks.AIR.defaultBlockState());

        // 2) cimientos y piso
        for (int lz = 0; lz < 7; lz++) {
            for (int lx = -3; lx <= 3; lx++) {
                for (int y = fy - 1; y >= fy - 6; y--) {
                    BlockPos p = at(base, right, dir, lx, lz, y);
                    BlockState cs = this.level().getBlockState(p);
                    if (cs.isAir() || cs.canBeReplaced() || !cs.getFluidState().isEmpty()) add(p, Blocks.COBBLESTONE.defaultBlockState());
                    else break;
                }
                add(at(base, right, dir, lx, lz, fy), Blocks.OAK_PLANKS.defaultBlockState());
            }
        }

        // 3) paredes
        for (int h = 1; h <= 4; h++) {
            for (int lz = 0; lz < 7; lz++) {
                for (int lx = -3; lx <= 3; lx++) {
                    boolean edge = lx == -3 || lx == 3 || lz == 0 || lz == 6;
                    if (!edge) continue;
                    if (lz == 0 && lx == 0 && h <= 2) continue; // puerta
                    boolean corner = Math.abs(lx) == 3 && (lz == 0 || lz == 6);
                    BlockState st;
                    if (corner) st = Blocks.OAK_LOG.defaultBlockState();
                    else if (h == 2 && isWindow(lx, lz)) st = Blocks.GLASS.defaultBlockState();
                    else st = Blocks.OAK_PLANKS.defaultBlockState();
                    add(at(base, right, dir, lx, lz, fy + h), st);
                }
            }
        }

        // 4) techo
        for (int lz = 0; lz < 7; lz++)
            for (int lx = -3; lx <= 3; lx++)
                add(at(base, right, dir, lx, lz, fy + 5), Blocks.OAK_PLANKS.defaultBlockState());

        // 5) puerta y decoracion
        BlockState door = Blocks.OAK_DOOR.defaultBlockState().setValue(DoorBlock.FACING, dir.getOpposite());
        add(at(base, right, dir, 0, 0, fy + 1), door.setValue(DoorBlock.HALF, DoubleBlockHalf.LOWER));
        add(at(base, right, dir, 0, 0, fy + 2), door.setValue(DoorBlock.HALF, DoubleBlockHalf.UPPER));
        add(at(base, right, dir, -2, 1, fy + 1), Blocks.TORCH.defaultBlockState());
        add(at(base, right, dir, 2, 1, fy + 1), Blocks.TORCH.defaultBlockState());
        add(at(base, right, dir, -2, 5, fy + 1), Blocks.CRAFTING_TABLE.defaultBlockState());
        add(at(base, right, dir, 2, 5, fy + 1), Blocks.CHEST.defaultBlockState().setValue(ChestBlock.FACING, dir.getOpposite()));

        this.buildCenter = at(base, right, dir, 0, 3, fy + 1);
        this.buildTimer = 0;
        return true;
    }

    private boolean applyStep(BuildStep s) {
        BlockState cur = this.level().getBlockState(s.pos());
        if (cur == s.state()) return false;
        if (cur.getDestroySpeed(this.level(), s.pos()) < 0 || this.level().getBlockEntity(s.pos()) != null) return false;
        if (s.state().isAir()) {
            this.level().destroyBlock(s.pos(), false);
        } else {
            this.level().setBlock(s.pos(), s.state(), 3);
            this.level().playSound(null, s.pos(), s.state().getSoundType().getPlaceSound(), SoundSource.BLOCKS, 1.0F, 1.0F);
        }
        this.swing(InteractionHand.MAIN_HAND);
        return true;
    }

    private void tickBuild() {
        if (buildQueue.isEmpty() || buildCenter == null) return;
        double cx = buildCenter.getX() + 0.5D, cz = buildCenter.getZ() + 0.5D;
        double d2 = this.distanceToSqr(cx, buildCenter.getY(), cz);
        if (d2 > 14.0D * 14.0D) {
            if (d2 > 48.0D * 48.0D) this.teleportTo(cx, buildCenter.getY(), cz - 4.0D);
            else if (this.tickCount % 10 == 0) this.getNavigation().moveTo(cx, buildCenter.getY(), cz, 1.2D);
            return;
        }
        if (--buildTimer > 0) return;
        buildTimer = Math.max(1, 20 / Config.BUILD_SPEED.get());
        while (!buildQueue.isEmpty()) {
            if (applyStep(buildQueue.poll())) break;
        }
        if (buildQueue.isEmpty()) {
            Player o = getOwner();
            if (o != null) o.sendSystemMessage(Component.literal("§d<" + Config.NAME.get() + ">§r ¡Terminé la casa! Pasa a verla."));
        }
    }

    // ---------- interaccion ----------
    @Override
    protected InteractionResult mobInteract(Player player, InteractionHand hand) {
        ItemStack held = player.getItemInHand(hand);
        if (held.isEmpty()) return InteractionResult.PASS;
        EquipmentSlot slot = Mob.getEquipmentSlotForItem(held);
        if (slot == EquipmentSlot.MAINHAND && !(held.getItem() instanceof SwordItem || held.getItem() instanceof AxeItem)) {
            return InteractionResult.PASS;
        }
        if (!this.level().isClientSide) {
            ItemStack old = this.getItemBySlot(slot);
            if (!old.isEmpty()) this.spawnAtLocation(old);
            this.setItemSlot(slot, held.split(1));
            this.setDropChance(slot, 1.0F);
        }
        return InteractionResult.sidedSuccess(this.level().isClientSide);
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        if (ownerId != null) tag.putUUID("Owner", ownerId);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.hasUUID("Owner")) ownerId = tag.getUUID("Owner");
    }

    static class FollowOwnerGoal extends Goal {
        private final ClaudeEntity mob;
        private int recalc;

        FollowOwnerGoal(ClaudeEntity mob) {
            this.mob = mob;
            this.setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
        }

        @Override
        public boolean canUse() {
            Player o = mob.getOwner();
            return o != null && !mob.isBuilding() && !o.isSpectator() && mob.distanceToSqr(o) > 36.0D;
        }

        @Override
        public boolean canContinueToUse() {
            Player o = mob.getOwner();
            return o != null && !mob.isBuilding() && mob.distanceToSqr(o) > 9.0D;
        }

        @Override
        public void tick() {
            Player o = mob.getOwner();
            if (o == null) return;
            mob.getLookControl().setLookAt(o, 10.0F, mob.getMaxHeadXRot());
            if (--recalc <= 0) {
                recalc = 10;
                if (mob.distanceToSqr(o) > 576.0D) {
                    mob.teleportTo(o.getX(), o.getY(), o.getZ());
                    mob.getNavigation().stop();
                } else {
                    mob.getNavigation().moveTo(o, 1.2D);
                }
            }
        }

        @Override
        public void stop() { mob.getNavigation().stop(); }
    }
}
