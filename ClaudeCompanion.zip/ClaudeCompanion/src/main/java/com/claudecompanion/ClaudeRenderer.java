package com.claudecompanion;

import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.client.renderer.entity.layers.HumanoidArmorLayer;
import net.minecraft.resources.ResourceLocation;

public class ClaudeRenderer extends HumanoidMobRenderer<ClaudeEntity, PlayerModel<ClaudeEntity>> {
    private static final ResourceLocation[] SKINS = new ResourceLocation[Config.NUM_SKINS];

    static {
        for (int i = 0; i < SKINS.length; i++) {
            SKINS[i] = new ResourceLocation("claudecompanion", "textures/entity/claude_" + i + ".png");
        }
    }

    public ClaudeRenderer(EntityRendererProvider.Context ctx) {
        super(ctx, new PlayerModel<>(ctx.bakeLayer(ModelLayers.PLAYER), false), 0.5F);
        this.addLayer(new HumanoidArmorLayer<>(this,
                new HumanoidModel<>(ctx.bakeLayer(ModelLayers.PLAYER_INNER_ARMOR)),
                new HumanoidModel<>(ctx.bakeLayer(ModelLayers.PLAYER_OUTER_ARMOR)),
                ctx.getModelManager()));
    }

    @Override
    public ResourceLocation getTextureLocation(ClaudeEntity entity) {
        int s = Math.max(0, Math.min(SKINS.length - 1, entity.getSkin()));
        return SKINS[s];
    }
}
