package com.claudecompanion;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public class ClaudeConfigScreen extends Screen {
    private static final String[] MODES = {"amigo", "bullying", "menso"};

    private final Screen parent;
    private EditBox key, model, name, hearts;
    private Button bProvider, bPersona, bSkin, bAll, bGive;
    private String provider, personality;
    private int skin;
    private boolean respondAll, allowGive;
    private int lx, rx, y0;

    public ClaudeConfigScreen(Screen parent) {
        super(Component.literal("Claude Companion - Ajustes"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        provider = Config.PROVIDER.get();
        personality = Config.PERSONALITY.get();
        skin = Config.SKIN.get();
        respondAll = Config.RESPOND_ALL.get();
        allowGive = Config.ALLOW_GIVE.get();

        int w = 150;
        lx = this.width / 2 - w - 5;
        rx = this.width / 2 + 5;
        y0 = 36;
        int gap = 32;

        key = new EditBox(this.font, lx, y0, w, 20, Component.literal("API key Gemini"));
        key.setMaxLength(256);
        key.setValue(Config.GEMINI_KEY.get());
        addRenderableWidget(key);

        model = new EditBox(this.font, lx, y0 + gap, w, 20, Component.literal("Modelo"));
        model.setMaxLength(100);
        model.setValue(Config.GEMINI_MODEL.get());
        addRenderableWidget(model);

        name = new EditBox(this.font, lx, y0 + gap * 2, w, 20, Component.literal("Nombre"));
        name.setMaxLength(24);
        name.setValue(Config.NAME.get());
        addRenderableWidget(name);

        hearts = new EditBox(this.font, lx, y0 + gap * 3, w, 20, Component.literal("Corazones"));
        hearts.setMaxLength(3);
        hearts.setValue(String.valueOf(Config.HEARTS.get()));
        addRenderableWidget(hearts);

        bProvider = addRenderableWidget(Button.builder(Component.empty(), b -> {
            provider = provider.equals("gemini") ? "claude" : "gemini";
            refresh();
        }).bounds(lx, y0 + gap * 4 - 6, w, 20).build());

        bPersona = addRenderableWidget(Button.builder(Component.empty(), b -> {
            int i = 0;
            for (int k = 0; k < MODES.length; k++) if (MODES[k].equals(personality)) i = k;
            personality = MODES[(i + 1) % MODES.length];
            refresh();
        }).bounds(rx, y0, w, 20).build());

        bSkin = addRenderableWidget(Button.builder(Component.empty(), b -> {
            skin = (skin + 1) % Config.NUM_SKINS;
            refresh();
        }).bounds(rx, y0 + 26, w, 20).build());

        bAll = addRenderableWidget(Button.builder(Component.empty(), b -> {
            respondAll = !respondAll;
            refresh();
        }).bounds(rx, y0 + 52, w, 20).build());

        bGive = addRenderableWidget(Button.builder(Component.empty(), b -> {
            allowGive = !allowGive;
            refresh();
        }).bounds(rx, y0 + 78, w, 20).build());

        addRenderableWidget(Button.builder(Component.literal("Guardar"), b -> {
            save();
            onClose();
        }).bounds(this.width / 2 - 105, this.height - 28, 100, 20).build());

        addRenderableWidget(Button.builder(Component.literal("Cancelar"), b -> onClose())
                .bounds(this.width / 2 + 5, this.height - 28, 100, 20).build());

        refresh();
    }

    private void refresh() {
        bProvider.setMessage(Component.literal("IA: " + provider));
        bPersona.setMessage(Component.literal("Personalidad: " + personality));
        bSkin.setMessage(Component.literal("Skin: " + (skin + 1) + "/" + Config.NUM_SKINS));
        bAll.setMessage(Component.literal("Responder a todo: " + (respondAll ? "SÍ" : "NO")));
        bGive.setMessage(Component.literal("Dar objetos: " + (allowGive ? "SÍ" : "NO")));
    }

    private void save() {
        Config.PROVIDER.set(provider);
        Config.GEMINI_KEY.set(key.getValue().trim());
        String m = model.getValue().trim();
        Config.GEMINI_MODEL.set(m.isEmpty() ? "gemini-flash-latest" : m);
        String n = name.getValue().trim();
        Config.NAME.set(n.isEmpty() ? "Claude" : n);
        int h;
        try {
            h = Integer.parseInt(hearts.getValue().trim());
        } catch (NumberFormatException e) {
            h = Config.HEARTS.get();
        }
        Config.HEARTS.set(Math.max(1, Math.min(512, h)));
        Config.PERSONALITY.set(personality);
        Config.SKIN.set(skin);
        Config.RESPOND_ALL.set(respondAll);
        Config.ALLOW_GIVE.set(allowGive);
        Config.SPEC.save();
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partial) {
        this.renderBackground(g);
        g.drawCenteredString(this.font, this.title, this.width / 2, 12, 0xFFFFFF);
        int gap = 32;
        g.drawString(this.font, "API key de Gemini", lx, y0 - 10, 0xA0A0A0);
        g.drawString(this.font, "Modelo de Gemini", lx, y0 + gap - 10, 0xA0A0A0);
        g.drawString(this.font, "Nombre", lx, y0 + gap * 2 - 10, 0xA0A0A0);
        g.drawString(this.font, "Corazones (1-512)", lx, y0 + gap * 3 - 10, 0xA0A0A0);
        super.render(g, mouseX, mouseY, partial);
    }

    @Override
    public void onClose() {
        this.minecraft.setScreen(parent);
    }
}
