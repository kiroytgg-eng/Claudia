package com.claudecompanion;

import com.google.gson.*;
import java.net.URI;
import java.net.http.*;
import java.time.Duration;

public class ClaudeClient {
    private static final HttpClient HTTP = HttpClient.newHttpClient();

    public static String ask(String system, JsonArray messages) throws Exception {
        if ("claude".equalsIgnoreCase(Config.PROVIDER.get())) return askAnthropic(system, messages);
        return askGemini(system, messages);
    }

    private static JsonObject obj() { return new JsonObject(); }

    private static String askGemini(String system, JsonArray messages) throws Exception {
        String key = Config.GEMINI_KEY.get().trim();
        if (key.isEmpty()) throw new IllegalStateException("Falta la geminiApiKey (pantalla de config o config/claudecompanion-common.toml)");
        String model = Config.GEMINI_MODEL.get().trim();
        if (model.startsWith("models/")) model = model.substring(7);

        JsonObject body = obj();
        JsonObject sys = obj();
        JsonArray sp = new JsonArray();
        JsonObject st = obj();
        st.addProperty("text", system);
        sp.add(st);
        sys.add("parts", sp);
        body.add("systemInstruction", sys);

        JsonArray contents = new JsonArray();
        for (JsonElement el : messages) {
            JsonObject m = el.getAsJsonObject();
            JsonObject c = obj();
            c.addProperty("role", "assistant".equals(m.get("role").getAsString()) ? "model" : "user");
            JsonArray parts = new JsonArray();
            JsonObject pt = obj();
            pt.addProperty("text", m.get("content").getAsString());
            parts.add(pt);
            c.add("parts", parts);
            contents.add(c);
        }
        body.add("contents", contents);
        JsonObject gc = obj();
        gc.addProperty("maxOutputTokens", 2000);
        gc.addProperty("temperature", 1.0);
        body.add("generationConfig", gc);

        HttpRequest req = HttpRequest.newBuilder(URI.create("https://generativelanguage.googleapis.com/v1beta/models/" + model + ":generateContent"))
                .header("content-type", "application/json")
                .header("x-goog-api-key", key)
                .timeout(Duration.ofSeconds(60))
                .POST(HttpRequest.BodyPublishers.ofString(body.toString()))
                .build();
        HttpResponse<String> res = HTTP.send(req, HttpResponse.BodyHandlers.ofString());
        if (res.statusCode() != 200) {
            throw new RuntimeException("Gemini HTTP " + res.statusCode() + ": " + res.body());
        }
        JsonObject json = JsonParser.parseString(res.body()).getAsJsonObject();
        StringBuilder sb = new StringBuilder();
        if (json.has("candidates") && json.getAsJsonArray("candidates").size() > 0) {
            JsonObject cand = json.getAsJsonArray("candidates").get(0).getAsJsonObject();
            if (cand.has("content") && cand.getAsJsonObject("content").has("parts")) {
                for (JsonElement e : cand.getAsJsonObject("content").getAsJsonArray("parts")) {
                    JsonObject o = e.getAsJsonObject();
                    if (o.has("text")) sb.append(o.get("text").getAsString());
                }
            }
        }
        if (sb.length() == 0) throw new RuntimeException("Gemini no devolvio texto (puede que lo bloqueara por seguridad)");
        return sb.toString();
    }

    private static String askAnthropic(String system, JsonArray messages) throws Exception {
        String key = Config.API_KEY.get();
        if (key == null || key.isBlank()) {
            throw new IllegalStateException("Falta la apiKey de Anthropic en config/claudecompanion-common.toml");
        }
        JsonObject body = obj();
        body.addProperty("model", Config.MODEL.get());
        body.addProperty("max_tokens", 700);
        body.addProperty("system", system);
        body.add("messages", messages);

        HttpRequest req = HttpRequest.newBuilder(URI.create("https://api.anthropic.com/v1/messages"))
                .header("content-type", "application/json")
                .header("x-api-key", key)
                .header("anthropic-version", "2023-06-01")
                .timeout(Duration.ofSeconds(60))
                .POST(HttpRequest.BodyPublishers.ofString(body.toString()))
                .build();
        HttpResponse<String> res = HTTP.send(req, HttpResponse.BodyHandlers.ofString());
        if (res.statusCode() != 200) {
            throw new RuntimeException("HTTP " + res.statusCode() + ": " + res.body());
        }
        JsonObject json = JsonParser.parseString(res.body()).getAsJsonObject();
        StringBuilder sb = new StringBuilder();
        for (JsonElement e : json.getAsJsonArray("content")) {
            JsonObject o = e.getAsJsonObject();
            if ("text".equals(o.get("type").getAsString())) sb.append(o.get("text").getAsString());
        }
        return sb.toString();
    }
}
