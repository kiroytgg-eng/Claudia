package com.claudecompanion;

import net.minecraftforge.common.ForgeConfigSpec;

import java.util.List;

public class Config {
    public static final int NUM_SKINS = 6;

    public static final ForgeConfigSpec SPEC;
    public static final ForgeConfigSpec.ConfigValue<String> PROVIDER;
    public static final ForgeConfigSpec.ConfigValue<String> GEMINI_KEY;
    public static final ForgeConfigSpec.ConfigValue<String> GEMINI_MODEL;
    public static final ForgeConfigSpec.ConfigValue<String> API_KEY;
    public static final ForgeConfigSpec.ConfigValue<String> MODEL;
    public static final ForgeConfigSpec.ConfigValue<String> NAME;
    public static final ForgeConfigSpec.ConfigValue<String> PERSONALITY;
    public static final ForgeConfigSpec.IntValue SKIN;
    public static final ForgeConfigSpec.IntValue HEARTS;
    public static final ForgeConfigSpec.IntValue BUILD_SPEED;
    public static final ForgeConfigSpec.BooleanValue RESPOND_ALL;
    public static final ForgeConfigSpec.BooleanValue ALLOW_GIVE;
    public static final ForgeConfigSpec.IntValue MAX_PER_GIVE;

    static {
        ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();
        PROVIDER = b.comment("Que IA usar: gemini o claude").defineInList("provider", "gemini", List.of("gemini", "claude"));
        GEMINI_KEY = b.comment("Tu API key de Google Gemini (aistudio.google.com/apikey)").define("geminiApiKey", "");
        GEMINI_MODEL = b.comment("Modelo de Gemini (si da error 404 pon otro, ej: gemini-2.5-flash)").define("geminiModel", "gemini-flash-latest");
        API_KEY = b.comment("API key de Anthropic (solo si provider=claude)").define("apiKey", "");
        MODEL = b.comment("Modelo de Claude (solo si provider=claude)").define("model", "claude-sonnet-5-5");
        NAME = b.comment("Nombre del companero").define("claudeName", "Claude");
        PERSONALITY = b.comment("Personalidad: amigo, bullying o menso").defineInList("personality", "amigo", List.of("amigo", "bullying", "menso"));
        SKIN = b.comment("Skin del cuerpo (0 a 5)").defineInRange("skin", 0, 0, NUM_SKINS - 1);
        HEARTS = b.comment("Corazones de vida (1 a 512)").defineInRange("hearts", 500, 1, 512);
        BUILD_SPEED = b.comment("Bloques por segundo al construir una casa").defineInRange("buildBlocksPerSecond", 4, 1, 20);
        RESPOND_ALL = b.comment("Si su cuerpo esta invocado (/claude spawn), responde a TODO lo que escribas. Si es false, solo cuando lo nombres").define("respondToAllWhenSpawned", true);
        ALLOW_GIVE = b.comment("Permitir que te de objetos").define("allowGive", true);
        MAX_PER_GIVE = b.comment("Maximo de unidades por objeto en cada entrega").defineInRange("maxPerGive", 64, 1, 2304);
        SPEC = b.build();
    }
}
