package com.claudecompanion;

import com.google.gson.*;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.entity.EntityTypeTest;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.regex.*;

public class ClaudeCommand {
    private static final Map<UUID, JsonArray> HISTORY = new HashMap<>();
    private static final Pattern GIVE = Pattern.compile("\\[\\[GIVE\\s+([a-z0-9_.-]+:[a-z0-9_/.-]+)\\s+(\\d+)\\]\\]");
    private static final String BUILD_TAG = "[[BUILD_HOUSE]]";

    public static void register(CommandDispatcher<CommandSourceStack> d) {
        d.register(Commands.literal("claude")
                .then(Commands.literal("spawn").executes(c -> {
                    spawn(c.getSource().getPlayerOrException());
                    return 1;
                }))
                .then(Commands.literal("despawn").executes(c -> {
                    removeBodies(c.getSource().getPlayerOrException());
                    return 1;
                }))
                .then(Commands.literal("reset").executes(c -> {
                    ServerPlayer p = c.getSource().getPlayerOrException();
                    HISTORY.remove(p.getUUID());
                    say(p, "Memoria de la conversación borrada.");
                    return 1;
                }))
                .then(Commands.literal("casa").executes(c -> {
                    ServerPlayer p = c.getSource().getPlayerOrException();
                    startHouse(p);
                    return 1;
                }))
                .then(Commands.literal("modo").then(Commands.argument("tipo", StringArgumentType.word())
                        .suggests((ctx, b) -> SharedSuggestionProvider.suggest(List.of("amigo", "bullying", "menso"), b))
                        .executes(c -> {
                            ServerPlayer p = c.getSource().getPlayerOrException();
                            String t = StringArgumentType.getString(c, "tipo").toLowerCase();
                            if (!List.of("amigo", "bullying", "menso").contains(t)) {
                                say(p, "Modos: amigo, bullying, menso.");
                                return 0;
                            }
                            Config.PERSONALITY.set(t);
                            Config.SPEC.save();
                            HISTORY.remove(p.getUUID());
                            say(p, "Modo cambiado a " + t + ".");
                            return 1;
                        })))
                .then(Commands.literal("nombre").then(Commands.argument("nuevo", StringArgumentType.greedyString())
                        .executes(c -> {
                            ServerPlayer p = c.getSource().getPlayerOrException();
                            String n = StringArgumentType.getString(c, "nuevo").trim();
                            if (n.isEmpty() || n.length() > 24) {
                                say(p, "El nombre debe tener entre 1 y 24 letras.");
                                return 0;
                            }
                            Config.NAME.set(n);
                            Config.SPEC.save();
                            say(p, "Ahora me llamo " + n + ".");
                            return 1;
                        })))
                .then(Commands.literal("skin").then(Commands.argument("numero", IntegerArgumentType.integer(1, Config.NUM_SKINS))
                        .executes(c -> {
                            ServerPlayer p = c.getSource().getPlayerOrException();
                            Config.SKIN.set(IntegerArgumentType.getInteger(c, "numero") - 1);
                            Config.SPEC.save();
                            say(p, "Skin cambiada.");
                            return 1;
                        })))
                .then(Commands.argument("mensaje", StringArgumentType.greedyString()).executes(c -> {
                    ask(c.getSource().getPlayerOrException(), StringArgumentType.getString(c, "mensaje"));
                    return 1;
                })));
    }

    // ---------- utilidades ----------
    private static void say(ServerPlayer p, String text) {
        p.sendSystemMessage(Component.literal("§d<" + Config.NAME.get() + ">§r " + text));
    }

    private static List<? extends ClaudeEntity> bodies(ServerPlayer p) {
        return p.serverLevel().getEntities(EntityTypeTest.forClass(ClaudeEntity.class),
                x -> p.getUUID().equals(x.getOwnerId()));
    }

    public static boolean hasBody(ServerPlayer p) {
        return !bodies(p).isEmpty();
    }

    private static void removeBodies(ServerPlayer p) {
        for (ClaudeEntity e : bodies(p)) e.discard();
    }

    private static void spawn(ServerPlayer p) {
        removeBodies(p);
        ServerLevel lvl = p.serverLevel();
        ClaudeEntity e = ModEntities.CLAUDE.get().create(lvl);
        if (e == null) return;
        e.moveTo(p.getX(), p.getY(), p.getZ(), p.getYRot(), 0.0F);
        e.setOwner(p);
        e.applyConfig();
        e.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.STONE_SWORD));
        lvl.addFreshEntity(e);
        say(p, "¡Ya estoy aquí contigo!");
    }

    private static void startHouse(ServerPlayer p) {
        List<? extends ClaudeEntity> list = bodies(p);
        if (list.isEmpty()) {
            say(p, "Para construir necesito mi cuerpo: usa /claude spawn.");
        } else if (list.get(0).startHouse(p)) {
            say(p, "¡Manos a la obra! Me voy a tardar un ratito.");
        } else {
            say(p, "Ya estoy construyendo, ten paciencia.");
        }
    }

    // ---------- IA ----------
    private static String systemPrompt(String playerName) {
        String name = Config.NAME.get();
        String mode = Config.PERSONALITY.get();
        boolean menso = "menso".equals(mode);

        String base = "Te llamas " + name + " y vives dentro de Minecraft Java 1.20.1 (Forge), en un cuerpo de jugador que sigue a " + playerName
                + " a todas partes. Respondes en español, en 1 a 3 frases cortas, sin markdown ni listas. "
                + "Recibes el estado del jugador antes de cada mensaje; úsalo pero no lo recites. ";

        String persona;
        switch (mode) {
            case "bullying":
                persona = "Personalidad: eres el amigo bully. Le haces burlas, bromas pesadas y sarcasmo de cuates sobre sus errores, su inventario y su forma de jugar, "
                        + "como un roast entre amigos, siempre en tono de juego y sin insultos de verdad (nada de odio, discriminación ni groserías fuertes). "
                        + "Aun así, a regañadientes, sí lo ayudas a pasarse el juego (llegar al End y vencer al Ender Dragon).";
                break;
            case "menso":
                persona = "Personalidad: eres muy menso. No sabes absolutamente nada de Minecraft ni de casi nada. Eres despistado, confundes las cosas, "
                        + "haces preguntas tontas y das respuestas disparatadas o inútiles. No sabes cómo pasarse el juego, no sabes dar objetos ni construir casas.";
                break;
            default:
                persona = "Personalidad: eres su mejor amigo, cercano, con humor y buena onda. Charlas de lo que sea y lo ayudas a pasarse el juego "
                        + "(llegar al End y vencer al Ender Dragon), diciéndole qué hacer según su estado, su inventario y lo que hay cerca.";
        }

        String tags = "";
        if (!menso) {
            if (Config.ALLOW_GIVE.get()) {
                tags += " Si te pide objetos, o ves que le harían falta para avanzar, puedes dárselos escribiendo AL FINAL de tu respuesta, una por línea, "
                        + "la etiqueta exacta [[GIVE id_del_objeto cantidad]], por ejemplo [[GIVE minecraft:iron_sword 1]]. Usa solo ids válidos de Minecraft 1.20.1.";
            }
            tags += " Si te pide que construyas una casa, o ves que no tiene refugio, escribe al final la etiqueta exacta " + BUILD_TAG
                    + " (la construyes poco a poco y tardas un rato; avísale).";
        }
        return base + persona + tags;
    }

    private static String context(ServerPlayer p) {
        Map<String, Integer> inv = new TreeMap<>();
        List<ItemStack> all = new ArrayList<>();
        all.addAll(p.getInventory().items);
        all.addAll(p.getInventory().armor);
        all.addAll(p.getInventory().offhand);
        for (ItemStack s : all) {
            if (s.isEmpty()) continue;
            ResourceLocation k = ForgeRegistries.ITEMS.getKey(s.getItem());
            inv.merge(k == null ? "?" : k.toString(), s.getCount(), Integer::sum);
        }
        Map<String, Integer> near = new TreeMap<>();
        for (LivingEntity x : p.level().getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(16), y -> y != p)) {
            ResourceLocation k = ForgeRegistries.ENTITY_TYPES.getKey(x.getType());
            near.merge(k == null ? "?" : k.getPath(), 1, Integer::sum);
        }
        String biome = p.level().getBiome(p.blockPosition()).unwrapKey().map(k -> k.location().toString()).orElse("?");
        return "[Estado: dimensión=" + p.level().dimension().location()
                + ", bioma=" + biome
                + ", pos=" + p.blockPosition().toShortString()
                + ", vida=" + (int) p.getHealth() + "/" + (int) p.getMaxHealth()
                + ", hambre=" + p.getFoodData().getFoodLevel()
                + ", hora=" + (p.level().getDayTime() % 24000)
                + ", inventario=" + inv + ", cerca(16 bloques)=" + near + "]";
    }

    public static void ask(ServerPlayer player, String text) {
        JsonArray hist = HISTORY.computeIfAbsent(player.getUUID(), k -> new JsonArray());
        while (hist.size() >= 12) hist.remove(0);
        while (hist.size() > 0 && !"user".equals(hist.get(0).getAsJsonObject().get("role").getAsString())) hist.remove(0);

        JsonObject um = new JsonObject();
        um.addProperty("role", "user");
        um.addProperty("content", context(player) + "\n" + text);
        hist.add(um);

        JsonArray snapshot = hist.deepCopy();
        String system = systemPrompt(player.getName().getString());
        var server = player.getServer();
        player.displayClientMessage(Component.literal("§7" + Config.NAME.get() + " está pensando..."), true);

        CompletableFuture.runAsync(() -> {
            try {
                String reply = ClaudeClient.ask(system, snapshot);
                server.execute(() -> deliver(player, reply));
            } catch (Exception ex) {
                server.execute(() -> {
                    JsonArray h = HISTORY.get(player.getUUID());
                    if (h != null && h.size() > 0) h.remove(h.size() - 1);
                    player.sendSystemMessage(Component.literal("§c<" + Config.NAME.get() + "> Error: " + ex.getMessage()));
                });
            }
        });
    }

    private static void deliver(ServerPlayer player, String reply) {
        JsonArray hist = HISTORY.computeIfAbsent(player.getUUID(), k -> new JsonArray());
        JsonObject am = new JsonObject();
        am.addProperty("role", "assistant");
        am.addProperty("content", reply);
        hist.add(am);

        boolean menso = "menso".equals(Config.PERSONALITY.get());
        List<String> given = new ArrayList<>();
        if (!menso && Config.ALLOW_GIVE.get()) {
            Matcher m = GIVE.matcher(reply);
            while (m.find()) {
                ResourceLocation rl = ResourceLocation.tryParse(m.group(1));
                if (rl == null || !ForgeRegistries.ITEMS.containsKey(rl)) continue;
                Item item = ForgeRegistries.ITEMS.getValue(rl);
                int left = Math.min(Integer.parseInt(m.group(2)), Config.MAX_PER_GIVE.get());
                int total = left;
                while (left > 0) {
                    int n = Math.min(left, item.getMaxStackSize());
                    ItemStack st = new ItemStack(item, n);
                    if (!player.getInventory().add(st)) player.drop(st, false);
                    left -= n;
                }
                given.add(total + "x " + rl);
            }
        }
        boolean build = !menso && reply.contains(BUILD_TAG);

        for (ClaudeEntity body : bodies(player)) body.swing(InteractionHand.MAIN_HAND);

        String clean = GIVE.matcher(reply).replaceAll("").replace(BUILD_TAG, "").trim();
        if (!clean.isEmpty()) say(player, clean);
        if (!given.isEmpty()) {
            player.sendSystemMessage(Component.literal("§a<" + Config.NAME.get() + "> te dio: " + String.join(", ", given)));
        }
        if (build) startHouse(player);
    }
}
